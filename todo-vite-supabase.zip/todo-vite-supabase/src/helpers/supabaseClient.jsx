import { createClient } from '@supabase/supabase-js';

const supabaseUrl = 'https://dughrhybqhphyweavuic.supabase.co';
const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImR1Z2hyaHlicWhwaHl3ZWF2dWljIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDg0MTM0NDEsImV4cCI6MjA2Mzk4OTQ0MX0.F-5FMTgbB4EqWF6oWlI9VmyRQHLkLB_VlOyetUm3KHU';

const supabase = createClient(supabaseUrl, supabaseAnonKey);
export default supabase;
